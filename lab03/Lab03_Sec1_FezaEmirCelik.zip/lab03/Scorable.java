public interface Scorable {
    int calculateScore();
}
