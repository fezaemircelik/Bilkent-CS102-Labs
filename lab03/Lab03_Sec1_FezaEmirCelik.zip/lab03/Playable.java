public interface Playable {
    void play();
    boolean win();
}
