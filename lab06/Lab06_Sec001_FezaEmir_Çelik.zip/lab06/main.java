public class main {
    public static void main(String[] args) {
        q1 asd = new q1();
        System.out.println(asd.getMaxBudget());
    }

}
